package com.ril.fb.rilfbcalatogservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RilFbCalatogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
