package com.ril.fb.util;

public enum OrderStatus {
	NEW_ORDER, CANCELLED, UPDATED, DELIVERED, PENDING;

}
