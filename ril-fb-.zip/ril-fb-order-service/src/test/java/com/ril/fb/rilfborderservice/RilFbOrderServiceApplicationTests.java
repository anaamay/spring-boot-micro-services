package com.ril.fb.rilfborderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RilFbOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
