package com.ril.fb.rilfbregistryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RilFbRegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
